package com.example.ramsay.utils

enum class State {
    EXPANDED, COLLAPSED, IDLE
}