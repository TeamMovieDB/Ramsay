package com.example.ramsay.view_model

class RestaurantViewModel {
}