package com.example.ramsay.database

import androidx.room.Dao

@Dao
interface RestaurantDao {

}